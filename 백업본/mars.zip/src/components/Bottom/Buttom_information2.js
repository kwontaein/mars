import "./Bottom_information2.scss";

export default function Bottom_Information2() {
  return (
    <div>
      <img
        id="Bottom_Line"
        src="./Main_cocktail/bottom_img/Bottom_Line.png"/>
      <div className="Bottom_content_container">
      <img id="bottom_logo2" src="./Main_cocktail/bottom_img/bottom_logo2.png"/>
        <div className="icon_container">
            <img id="icon_items" src="./Main_cocktail/bottom_img/instagram_icon.png"/>
            <img id="icon_items2" src="./Main_cocktail/bottom_img/home_icon.png"/>
        </div>
      </div>
    </div>
  );
}
