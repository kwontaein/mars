import "./Guide.scss"

export default function Guide(){
    return(
        <div className="Guide_container">
            <div id="Guide_top_txt">VR 제과 · 제빵기능사 가이드</div>
        </div>

    )
}